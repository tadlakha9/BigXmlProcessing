#!/bin/ksh

JAVA_HOME=zulu1.8.0_66-8.11.0.1-win64

$JAVA_HOME/bin/java.exe  -jar bigxmlprocessing-server-0.0.1-SNAPSHOT.jar &

xdg-open http://localhost:8090/
